//
//  Data.swift
//  LoginSwiftUI_JoseLopezVilchez
//
//  Created by dam2 on 6/3/25.
//

import Foundation

class Data : ObservableObject {
    @Published var login : Bool = true;
}
