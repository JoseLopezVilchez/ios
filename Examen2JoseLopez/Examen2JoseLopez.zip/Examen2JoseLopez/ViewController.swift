//
//  ViewController.swift
//  Examen2JoseLopez
//
//  Created by dam2 on 5/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

